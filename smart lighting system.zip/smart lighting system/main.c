#include "header.h"

int main()
{
char a[13];
float vout;
 unsigned int result;
 uart_init(9600);
 spi_init();
 lcd_init();
  while(1)
 {
 result= mcp3204_read(2);
  sprintf(a,"%d",result);
   uart_tx_str(a);
     if(result>2500)
  {
   IOCLR0|=1<<18;
   lcd_cmd(0xc0);
   lcd_str("led ON");
  }
   else
   {
   lcd_cmd(0xc0);
   lcd_str("led OFF");
   IOSET0|=1<<18;
   }
   lcd_cmd(0x80);
  vout=100-((result*100)/4095);
  sprintf(a,"%.1f",vout);
  lcd_str(a);
  lcd_data('%');
   delay_ms(200);
   uart_tx_str("\r\n");	
  }
}	 
  


/*   //printing potentiometer on lcd..........
int main()
{
char a[13];
float vout;
unsigned int result;
uart_init(9600);
spi_init();
lcd_init();
lcd_data('a');
while(1)
{
 result=mcp3204_read(1);
 sprintf(a,"%d",result);
 uart_tx_str(a);
 uart_tx_str("\r\n");
  vout=((3.3*result)/4095);
  sprintf(a,"%.2f",vout);
  lcd_cmd(0x01);
  lcd_str(a);
  lcd_data('v');
  delay_ms(1000);
}
}
   
  */


/*
   int main()
{
char a[13];
float vout;
unsigned int result;
uart_init(9600);
spi_init();
lcd_init();
IODIR0=1<<18;
IOSET0=1<<18;
lcd_data('a');
while(1)
{
 result=mcp3204_read(2);
 sprintf(a,"%d",result);
 uart_tx_str(a);
  uart_tx_str("\r\n");
  if(result>2500)
  {
   IOCLR0=1<<18;
   lcd_cmd(0xc0);
   lcd_str("led ON");
  }
   else
   {
   lcd_cmd(0xc0);
   lcd_str("led OFF");
   IOSET0=1<<18;
   }
   lcd_cmd(0x80);
  vout=100-((result*100)/4095);
  sprintf(a,"%.1f",vout);
  lcd_str(a);
  lcd_data('%');
  delay_ms(1000);
  lcd_cmd(0x01);
}
}

  */



