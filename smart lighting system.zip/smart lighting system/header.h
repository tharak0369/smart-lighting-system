#include<lpc21xx.h>
#include<stdio.h>
void spi_init(void);
 unsigned int spi_read(char data);
   unsigned int mcp3204_read(char ch_num);
   void uart_tx(char data);
   void delay_ms(unsigned int ms);
   void uart_tx_str(char *p);
    void uart_init(unsigned int baud);

	void lcd_cmd(unsigned char cmd);
	void lcd_data(unsigned char data);
	 void lcd_str(char *p);
	 void lcd_init(void);
