#include<lpc21xx.h>
#include "header.h"

void spi_init(void)
{
PINSEL0|=0X1500;
IODIR0|=(1<<7);
IOSET0|=(1<<7);
S0SPCR=0X20;
S0SPCCR=15;
}


 unsigned int spi_read(char data)
 {
 //unsigned char temp;
 S0SPDR=data;
  IODIR0|=1<<18;
 IOSET0|=1<<18;
 while(((S0SPSR>>7)&1)==0);
 //temp=S0SPDR;
 return S0SPDR;
 }

  unsigned int mcp3204_read(char ch_num)
  {
   unsigned int result=0;
   unsigned char byteL=0,byteH=0;
   ch_num=ch_num<<6;
   IOCLR0|=(1<<7);
   spi_read(0x06);
   byteH=spi_read(ch_num);
   byteL=spi_read(0x0);
   IOSET0|=(1<<7);
   byteH&=0x0f;
   result=(byteH<<8)|byteL;
   return result;
  }

  void uart_init(unsigned int baud)
  {
   char a[]={15,60,30,15};
   unsigned int result,pclk;
   pclk=a[VPBDIV]*1000000;
   result=pclk/(16*baud);
   PINSEL0|=0X05;
   U0LCR=0X83;
   U0DLL=(result&0xff);
   U0DLM=(result>>8)&0xff;
   U0LCR=0X03;
  }

  void uart_tx(char data)
  {
   U0THR=data;
   while(((U0LSR>>5)&1)==0);
  }

  void delay_ms(unsigned int ms)
  {
  T0TC=0;
  T0PC=0;
  T0PR=15000-1;
  T0TCR=1;
  while(T0TC<ms);
  T0TCR=0;
  }

  void uart_tx_str(char *p)
  {
   while(*p)
   {
	U0THR=*p;
	while(((U0LSR>>5)&1)==0);
	p++;
   }
  }












